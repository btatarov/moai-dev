--==============================================================
-- Copyright (c) 2010-2011 Zipline Games, Inc. 
-- All Rights Reserved. 
-- http://getmoai.com
--==============================================================

local win = {}
statemgr.makePopup ( win )

win.layerTable = nil
local mainLayer = nil

local initX, initY = 0, 1280
local SLIDE_TIME = .2

local sparkParticles = nil

local shade = nil
local winScreen = nil
local animStarted = false

local music

----------------------------------------------------------------
-- local functions
----------------------------------------------------------------
local function showAnim ()
	
	local thread = MOAIThread.new ()
	thread:run (
		
		function ()
		
			MOAIThread.blockOnAction ( shade:seekColor ( 0, 0, 0, .5, SLIDE_TIME, MOAIEaseType.LINEAR ))
			
			music:play ()
			winScreen:setVisible ( true )
			winScreen:start ()
			animStarted = true
			
			repeat coroutine.yield () until not winScreen:isBusy ()
			util.waitSeconds (.5 )
			statemgr.pop ()
		end
	)
end

----------------------------------------------------------------
-- state functions
----------------------------------------------------------------
win.onFocus = function ( self )

	animStarted = false
	showAnim ()
end

----------------------------------------------------------------
win.onInput = function ( self )

end

----------------------------------------------------------------
win.onLoad = function ( self )

	self.layerTable = {}
	mainLayer = MOAILayer2D.new ()
	mainLayer:setViewport ( viewport )
	self.layerTable [ 1 ] = {  mainLayer }

	local tex = MOAITexture.new ()
	tex:load ( "resources/white.png" )
	tex:setWrap ( true )
	
	local gfxQuad = MOAIGfxQuad2D.new ()
	gfxQuad:setTexture ( tex )
	gfxQuad:setRect ( -640, -480, 640, 480 )
	
	shade = graphics.createSprite ()
	shade:setDeck ( gfxQuad )
	shade:setLayer ( mainLayer )
	shade:setColor ( 0, 0, 0, 0 )
	shade:setPriority ( 1 )
	
	winScreen = graphics.createSprite ()
	flash.decorateAsFlashAnim ( winScreen )
	winScreen:setDeck ( winScreen:loadFlashFlipbookAnim ( { filename = TROPICS_MOUNT_POINT .. "/resources/WS_TropicalFlipbookJackpot.fla.lua", startFrame = 1, endFrame = 48 }))
	winScreen:setAnimSpan ( 1, 48 ) 
	winScreen:setLayer ( mainLayer )
	winScreen:setPriority ( 2 )	
	winScreen:setVisible ( false )
	
	music = soundmgr.createSound ( TROPICS_MOUNT_POINT .. "/resources/sound/tropical_jackpot.ogg" )
end

----------------------------------------------------------------
win.onLoseFocus = function ( self )
	
	winScreen:stop ()
	winScreen:setVisible ( false )
	MOAIThread.blockOnAction ( shade:seekColor ( 0, 0, 0, 0, SLIDE_TIME, MOAIEaseType.LINEAR ))
end

----------------------------------------------------------------
win.onUnload = function ( self )
	
	for i, layerSet in ipairs ( self.layerTable ) do
		
		for j, layer in ipairs ( layerSet ) do
		
			layer = nil
		end
	end
	
	self.layerTable = nil
	mainLayer = nil

end

----------------------------------------------------------------
win.onUpdate = function ( self )

end

return win