--==============================================================
-- Copyright (c) 2010-2011 Zipline Games, Inc. 
-- All Rights Reserved. 
-- http://getmoai.com
--==============================================================

local win = {}
statemgr.makePopup ( win )

win.layerTable = nil
local mainLayer = nil

local initX, initY = 0, 1280
local SLIDE_TIME = .2

local sparkParticles = nil

local shade = nil
local winScreen = nil
local particles = nil
local animStarted = false

local emitter = {}
local particleAnim = {}

local music

----------------------------------------------------------------
-- local functions
----------------------------------------------------------------
local function showAnim ()
	
	local thread = MOAIThread.new ()
	thread:run (
		
		function ()
		
			MOAIThread.blockOnAction ( shade:seekColor ( 0, 0, 0, .5, SLIDE_TIME, MOAIEaseType.LINEAR ))

			particleAnim [ 1 ]:start ()
			particleAnim [ 2 ]:start ()
			particleAnim [ 3 ]:start ()
			particleAnim [ 4 ]:start ()
			particleAnim [ 5 ]:start ()
			particleAnim [ 6 ]:start ()
						
			music:play ()
			winScreen:setVisible ( true )
			winScreen:start ()
			animStarted = true
			
			util.waitSeconds ( .25 )
			emitter [ 1 ]:start ()
			emitter [ 2 ]:start ()
			emitter [ 3 ]:start ()
			emitter [ 4 ]:start ()
			emitter [ 5 ]:start ()
			emitter [ 6 ]:start ()
			
			repeat coroutine.yield () until not winScreen:isBusy ()
			
			emitter [ 1 ]:stop ()
			emitter [ 2 ]:stop ()
			emitter [ 3 ]:stop ()
			emitter [ 4 ]:stop ()
			emitter [ 5 ]:stop ()
			emitter [ 6 ]:stop ()
			
			util.waitSeconds ( .5 )
			statemgr.pop ()
		end
	)
end

----------------------------------------------------------------
-- state functions
----------------------------------------------------------------
win.onFocus = function ( self )

	animStarted = false
	showAnim ()
end

----------------------------------------------------------------
win.onInput = function ( self )

end

----------------------------------------------------------------
win.onLoad = function ( self )

	self.layerTable = {}
	mainLayer = MOAILayer2D.new ()
	mainLayer:setViewport ( viewport )
	self.layerTable [ 1 ] = {  mainLayer }

	local tex = MOAITexture.new ()
	tex:load ( "resources/white.png" )
	tex:setWrap ( true )
	
	local gfxQuad = MOAIGfxQuad2D.new ()
	gfxQuad:setTexture ( tex )
	gfxQuad:setRect ( -640, -480, 640, 480 )
	
	shade = graphics.createSprite ()
	shade:setDeck ( gfxQuad )
	shade:setLayer ( mainLayer )
	shade:setColor ( 0, 0, 0, 0 )
	shade:setPriority ( 1 )
	
	winScreen = graphics.createSprite ()
	flash.decorateAsFlashAnim ( winScreen )
	winScreen:setDeck ( winScreen:loadFlashFlipbookAnim ( { filename = TROPICS_MOUNT_POINT .. "/resources/WS_TropicalFlipbook.fla.lua", startFrame = 8, endFrame = 46 }))
	winScreen:setAnimSpan ( 1, 39 ) 
	winScreen:setLayer ( mainLayer )
	winScreen:setPriority ( 2 )	
	winScreen:setVisible ( false )
	
	particles = util.doFile ( TROPICS_MOUNT_POINT .. "/particles/particles-bubble-burst2.lua" )
	particles:setLayer ( mainLayer )
	particles:setPriority ( 1 )
	
	local transform = {}	
	for i = 1, 6 do
		transform [ i ] = MOAIProp2D.new ()
	
		emitter [ i ] = MOAIParticleTimedEmitter.new ()
		emitter [ i ]:setAngle ( 85, 95 ) 
		emitter [ i ]:setLoc ( 0, 0 )
		emitter [ i ]:setSystem ( particles:getSystem () )
		emitter [ i ]:setMagnitude ( 3, 8 )
		emitter [ i ]:setFrequency ( 0.02 )
		emitter [ i ]:setRadius ( 0 )
		emitter [ i ]:setParent ( transform [ i ] )
	end
	
	local function makeQuickCurve ( t )
		local curve = MOAIAnimCurve.new ()
		curve:reserveKeys ( #t )
		for i = 1, #t do curve:setKey ( i, t[i].t, t[i].v, t[i].et or MOAIEaseType.LINEAR ) end
		return curve
	end
	
	local curveX, curveY = {}, {}
	curveX [ 1 ] = makeQuickCurve ( { { t=0,v=1121-480 }, { t=0.1, v=1121-480 }, { t=1.9, v=98-480 } } )
	curveY [ 1 ] = makeQuickCurve ( { { t=0,v=320-583 },  { t=0.1, v=320-583 },  { t=1.9, v=320+141 } } )
	curveX [ 2 ] = makeQuickCurve ( { { t=0,v=926-480 },  { t=0.1, v=926-480 },  { t=1.9, v=-87-480 } } )
	curveY [ 2 ] = makeQuickCurve ( { { t=0,v=320-802 },  { t=0.1, v=320-802 },  { t=1.9, v=320-78 } } )
	curveX [ 3 ] = makeQuickCurve ( { { t=0,v=1044-480 }, { t=0.75,v=1044-480 }, { t=1.9, v=492-480 } } )
	curveY [ 3 ] = makeQuickCurve ( { { t=0,v=320-365 },  { t=0.75,v=320-365 },  { t=1.9, v=320+87 } } )
	curveX [ 4 ] = makeQuickCurve ( { { t=0,v=456-480 },  { t=1.0, v=456-480 },  { t=2.4, v=-110-480 } } )
	curveY [ 4 ] = makeQuickCurve ( { { t=0,v=320-730 },  { t=1.0, v=320-730 },  { t=2.4, v=320-249 } } )
	curveX [ 5 ] = makeQuickCurve ( { { t=0,v=985-480 },  { t=1.25,v=985-480 },  { t=3.1, v=94-480 } } )
	curveY [ 5 ] = makeQuickCurve ( { { t=0,v=320-699 },  { t=1.25,v=320-699 },  { t=3.1, v=320+87 } } )
	curveX [ 6 ] = makeQuickCurve ( { { t=0,v=1181-480 }, { t=1.25,v=1181-480 }, { t=2.75,v=444-480 } } )
	curveY [ 6 ] = makeQuickCurve ( { { t=0,v=320-471 },  { t=1.25,v=320-471 },  { t=2.75,v=320+163 } } )
	
	for i = 1, 6 do
		particleAnim [ i ] = MOAIAnim.new ()
		particleAnim [ i ]:reserveLinks ( 2 )
		particleAnim [ i ]:setLink ( 1, curveX [ i ], transform [ i ], MOAITransform.ATTR_X_LOC )
		particleAnim [ i ]:setLink ( 2, curveY [ i ], transform [ i ], MOAITransform.ATTR_Y_LOC )
		particleAnim [ i ]:setMode ( MOAITimer.NORMAL )
	end
	
	music = soundmgr.createSound ( TROPICS_MOUNT_POINT .. "/resources/sound/tropical_medwin.ogg" )
end

----------------------------------------------------------------
win.onLoseFocus = function ( self )
	
	winScreen:stop ()
	winScreen:setVisible ( false )
	MOAIThread.blockOnAction ( shade:seekColor ( 0, 0, 0, 0, SLIDE_TIME, MOAIEaseType.LINEAR ))
end

----------------------------------------------------------------
win.onUnload = function ( self )
	
	for i, layerSet in ipairs ( self.layerTable ) do
		
		for j, layer in ipairs ( layerSet ) do
		
			layer = nil
		end
	end
	
	self.layerTable = nil
	mainLayer = nil

end

----------------------------------------------------------------
win.onUpdate = function ( self )

end

return win