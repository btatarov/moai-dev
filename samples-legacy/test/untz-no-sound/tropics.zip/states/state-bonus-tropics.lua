--==============================================================
-- Copyright (c) 2010-2011 Zipline Games, Inc. 
-- All Rights Reserved. 
-- http://getmoai.com
--==============================================================

local bonus = {}
statemgr.makePopup ( bonus )

bonus.layerTable = nil
local mainLayer = nil
local bonusLayer = nil
local backLayer = nil
local bonusViewport = nil

local returndata = nil
local REWARDS = nil
local defaultRewards = {	
	{ successes = 5, weight = 10 },
	{ successes = 4, weight = 50 },
	{ successes = 3, weight = 200 },
	{ successes = 2, weight = 2000 },
	{ successes = 1, weight = 8000 },
	{ successes = 0, weight = 10000 }
}

local INTRO_ANIM = 1
local FIRST_TOUCH = 2
local NEXT_TOUCH = 3
local REVEAL_PICK = 4
local DONE = 5
local state = INTRO_ANIM

local oh, scuttle, bonusMusic

----------------------------------------------------------------
-- local functions
----------------------------------------------------------------
local function doLoss ( bucketIdx )
	
	-- setup
	local doneScreen = graphics.createSprite ()
	doneScreen:setDeck ( res.tropics.bonus )
	doneScreen:setIndex ( 6 )
	doneScreen:setLayer ( bonusLayer )
	doneScreen:setPriority ( 5 )
	doneScreen:setVisible ( false )
	
	local bonusText = graphics.createTextbox ()
	bonusText:setFont ( font.load ( TROPICS_MOUNT_POINT .. "/resources/font/hpunk16" ))
	bonusText:setSize ( 300, 50 )
	bonusText:setLoc ( 0, 50 )
	bonusText:setColor ( 1/255, 111/255, 223/255, 1 )
	bonusText:setAlignment ( MOAITextBox.CENTER_JUSTIFY )
	bonusText:setLayer ( bonusLayer )
	bonusText:setVisible ( false )
	
	local betText = graphics.createTextbox ()
	betText:setFont ( font.load ( TROPICS_MOUNT_POINT .. "/resources/font/hpunk16" ))
	betText:setSize ( 300, 50 )
	betText:setLoc ( 0, 0 )
	betText:setColor ( 1/255, 111/255, 223/255, 1 )
	betText:setAlignment ( MOAITextBox.CENTER_JUSTIFY )
	betText:setLayer ( bonusLayer )
	betText:setVisible ( false )
	
	local totalText = graphics.createTextbox ()
	totalText:setFont ( font.load ( TROPICS_MOUNT_POINT .. "/resources/font/hpunk16" ))
	totalText:setSize ( 300, 50 )
	totalText:setLoc ( 0, -50 )
	totalText:setColor ( 1/255, 111/255, 223/255, 1 )
	totalText:setAlignment ( MOAITextBox.CENTER_JUSTIFY )
	totalText:setLayer ( bonusLayer )
	totalText:setVisible ( false )
	
	-- script
	bonusMusic:seekVolume ( 0, 1 )	
	util.waitSeconds ( 1 )	
	doneScreen:setVisible ( true )
	bonusText:setText ( "Bonus:   x" .. bonus.maxSuccesses )
		
	util.waitSeconds ( .3 )
	betText:setText ( "Bet:   " ..  returndata.bet )
	
	util.waitSeconds ( .3 )
	totalText:setText ( "Total:   " ..  ( returndata.bet * bonus.maxSuccesses ))
	
	util.waitSeconds ( 2 )
	state = DONE
end

----------------------------------------------------------------
local function doWin ( bucketIdx )
	
	-- setup
	local crab = graphics.createSprite ()
	crab:setDeck ( res.tropics.bonus )
	crab:setIndex ( 4 )
	crab:setLayer ( bonusLayer )
	crab:setPriority ( 2 )
	crab:setLoc ( bonus.buckets.list [ bucketIdx ]:getLoc ())
	
	local crabJump = graphics.createSprite ()
	flash.decorateAsFlashAnim ( crabJump )
	crabJump:setDeck ( crabJump:loadFlashFlipbookAnim ( { filename = TROPICS_MOUNT_POINT .. "/resources/WS_TropicalFlipbookBonus.fla.lua", startFrame = 24, endFrame = 28 }))
	crabJump:setAnimSpan ( 1, 5 )
	crabJump:setPriority ( 2 )
	crabJump:setLoc ( bonus.buckets.list [ bucketIdx ]:getLoc ())
	crabJump:setLayer ( bonusLayer )
	crabJump:setVisible ( false )
	
	local crabWalk = graphics.createSprite ()
	flash.decorateAsFlashAnim ( crabWalk )
	crabWalk:setDeck ( crabWalk:loadFlashFlipbookAnim ( { filename = TROPICS_MOUNT_POINT .. "/resources/WS_TropicalFlipbookBonus.fla.lua", startFrame = 30, endFrame = 41 }))
	crabWalk:setAnimSpan ( 1, 12 )
	crabWalk:setPriority ( 4 )
	crabWalk:setLoc ( bonus.buckets.list [ bucketIdx ]:getLoc ())
	crabWalk:setLayer ( bonusLayer )
	crabWalk:setVisible ( false )
	
	local particles = util.doFile ( TROPICS_MOUNT_POINT .. "/particles/particles-flower-burst.lua" )
	particles:setLayer ( mainLayer )
	particles:setPriority ( 4 )
	
	local multText = graphics.createSprite ()
	multText:setDeck ( res.tropics.bonus )
	multText:setIndex ( 10 + bonus.totalSuccesses ) -- 10 is the first mult index, 10 + 1 = "x1", 10 + 2 = "x2", etc.
	multText:setLoc ( bonus.buckets.list [ bucketIdx ]:getLoc ())
	multText:setPriority ( 3 )
	multText:setLayer ( bonusLayer )
	multText:setVisible ( false )
	multText:setScl ( 0, 0 )
	
	-- script
	util.waitSeconds ( .45 )
	crab:setVisible ( false )
	crabJump:setVisible ( true )
	oh:play ()
	crabJump:start ()
	repeat coroutine.yield () until not crabJump:isBusy ()
		
	crabJump:setVisible ( false )
	crabWalk:setVisible ( true )
	crabWalk:start ()
	scuttle:play ()
	--particles:emit ( multText:getLoc ())
	repeat coroutine.yield () until not crabWalk:isBusy ()
		
		
	multText:setVisible ( true )	
	multText:seekScl ( .8, .8, .1, MOAIEaseType.LINEAR )
	util.waitSeconds ( .1 )
	multText:seekScl ( .6, .6, .0275, MOAIEaseType.LINEAR )
	util.waitSeconds ( 1 )
		
	crabWalk:setVisible ( false )
	multText:setVisible ( false )
	bonus.buckets.revealAnim:setMode ( MOAITimer.REVERSE )
	bonus.buckets.revealAnim:start ()
	repeat coroutine.yield () until not bonus.buckets.revealAnim:isBusy ()
		
	bonus.buckets.revealAnim:setVisible ( false )
	bonus.buckets.list [ bucketIdx ]:setVisible ( true )		
	state = NEXT_TOUCH
end

----------------------------------------------------------------
local function evaluatePick ( bucketIdx )
	
	local thread = MOAIThread.new ()
	state = REVEAL_PICK
	
	if bonus.totalSuccesses < bonus.maxSuccesses then
		bonus.totalSuccesses = bonus.totalSuccesses + 1
		thread:run ( doWin, bucketIdx )
	else
		thread:run ( doLoss, bucketIdx )
	end
end

----------------------------------------------------------------
local function createBuckets ()
	
	local buckets = {}
	buckets.list = {}
		
	-- bucket sprites	
	local bucket = graphics.createSprite ()
	bucket:setDeck ( res.tropics.bonus )
	bucket:setIndex ( 3 )
	bucket:setLoc ( -175, 55 )	
	bucket:setLayer ( bonusLayer )
	bucket:setPriority ( 3 )
	bucket:setVisible ( false )
	table.insert ( buckets.list, bucket)
	
	bucket = graphics.createSprite ()
	bucket:setDeck ( res.tropics.bonus )
	bucket:setIndex ( 3 )
	bucket:setLoc ( 10, -75 )
	bucket:setLayer ( bonusLayer )
	bucket:setPriority ( 5 )
	bucket:setVisible ( false )
	table.insert ( buckets.list, bucket)
	
	bucket = graphics.createSprite ()
	bucket:setDeck ( res.tropics.bonus )
	bucket:setIndex ( 3 )
	bucket:setLoc ( 170, 95 )
	bucket:setLayer ( bonusLayer )
	bucket:setPriority ( 3 )
	bucket:setVisible ( false )
	table.insert ( buckets.list, bucket)
	
	-- bucket anim
	buckets.revealAnim = graphics.createSprite ()
	flash.decorateAsFlashAnim ( buckets.revealAnim )
	buckets.revealAnim:setDeck ( buckets.revealAnim:loadFlashFlipbookAnim ( { filename = TROPICS_MOUNT_POINT .. "/resources/WS_TropicalFlipbookBonus.fla.lua", startFrame = 15, endFrame = 22 }))
	buckets.revealAnim:setAnimSpan ( 1, 8 )
	buckets.revealAnim:setSpeed ( 1.5 )
	buckets.revealAnim:setLayer ( bonusLayer )
	buckets.revealAnim:setPriority ( 3 )
	buckets.revealAnim:setVisible ( false )

	-------------------
	buckets.handleTouch = function ( self, x, y )
			
		local bnsX, bnsY = bonusLayer:wndToWorld ( x, y )
		for i, v in ipairs ( self.list ) do
			
			if v:inside ( bnsX, bnsY ) then
				
				if state == FIRST_TOUCH then bonus.crabWords:setVisible ( false ) end
				
				buckets.revealAnim:setLoc ( v:getLoc ())
				local thread = MOAIThread.new ()
				thread:run (
					function ()
						
						v:setVisible ( false )
						buckets.revealAnim:setMode ( MOAITimer.NORMAL )
						buckets.revealAnim:setVisible ( true )
						buckets.revealAnim:start ()
						evaluatePick ( i )
					end
				)
				break
			end
		end
	end
	
	-------------------
	buckets.setVisible = function ( self, visible )
		
		for i, v in ipairs ( self.list ) do
			
			v:setVisible ( visible )
		end
	end
	
	-------------------
	return buckets
end

----------------------------------------------------------------
local function getBonus ()
	
	local rand = math.random ( REWARDS [ #REWARDS ].weight )
	local val = #REWARDS
	
	for i = #REWARDS, 1, -1 do
		if REWARDS [ i ].weight < rand then break end
		val = i
	end
	
	return REWARDS [ val ].successes
end

----------------------------------------------------------------
local function runIntroAnim ()
	
	local thread = MOAIThread.new ()
	thread:run ( 
	
		function ()
						
			bonus.shade:seekColor ( 0, 0, 0, .5, .5, MOAIEaseType.LINEAR )
			util.waitSeconds ( .5 )

			bonus.frame:setVisible ( true )
			bonus.sandBG:setVisible ( true )
			bonus.crabWords:setVisible ( true )			
			bonus.buckets:setVisible ( true )
			bonus.waves:setVisible ( true )
			
			state = FIRST_TOUCH
		end
	)
end

----------------------------------------------------------------
-- state functions
----------------------------------------------------------------
bonus.onFocus = function ( self )

	bonusMusic:play ()
	runIntroAnim ()
	bonus.maxSuccesses = getBonus ()
	bonus.totalSuccesses = 0
	returndata.multiplier = bonus.maxSuccesses
end

----------------------------------------------------------------
bonus.onInput = function ( self )

	local x, y = inputmgr.getTouch ()
	
	if inputmgr.up () then
		
		if state == FIRST_TOUCH or state == NEXT_TOUCH then
			
			bonus.buckets:handleTouch ( x, y )
			
		end
	end
end

----------------------------------------------------------------
bonus.onLoad = function ( self, bonusdata )

	local viewWidth = SCREEN_WIDTH * ( 605/960 )
	local viewHeight = SCREEN_HEIGHT * ( 409/640 )
	local xOffset, yOffset = 0, 0
	local xStart, yStart = ( SCREEN_WIDTH - viewWidth ) / 2, ( SCREEN_HEIGHT - viewHeight ) / 2
	
	bonus_viewport:setSize ( SCREEN_X_OFFSET + xStart + xOffset, SCREEN_Y_OFFSET + yStart + yOffset, SCREEN_X_OFFSET + xStart + xOffset + viewWidth, SCREEN_Y_OFFSET + yStart + yOffset + viewHeight )
	bonus_viewport:setScale ( SCREEN_UNITS_X-(xStart*2), SCREEN_UNITS_Y-(yStart*2) )	
	
	self.layerTable = {}
	
	backLayer = MOAILayer2D.new ()
	backLayer:setViewport ( viewport )
	
	bonusLayer = MOAILayer2D.new ()
	bonusLayer:setViewport ( bonus_viewport )
	
	mainLayer = MOAILayer2D.new ()
	mainLayer:setViewport ( viewport )
	
	self.layerTable [ 1 ] = { backLayer, bonusLayer, mainLayer }
	
	-- data
	returndata = bonusdata	
	REWARDS = ( gamestate.bonusRewards ) and gamestate.bonusRewards.diner or defaultRewards

	-- darken gameplay
	local tex = MOAITexture.new ()
	tex:load ( "resources/white.png" )
	tex:setWrap ( true )
	
	local gfxQuad = MOAIGfxQuad2D.new ()
	gfxQuad:setTexture ( tex )
	gfxQuad:setRect ( -640, -480, 640, 480 )
	
	bonus.shade = graphics.createSprite ()
	bonus.shade:setDeck ( gfxQuad )
	bonus.shade:setLayer ( backLayer )
	bonus.shade:setColor ( 0, 0, 0, 0 )
	bonus.shade:setPriority ( 1 )
	
	-- frame
	bonus.frame = graphics.createSprite ()
	bonus.frame:setDeck ( res.tropics.bonus )
	bonus.frame:setIndex ( 1 )
	bonus.frame:setLayer ( mainLayer )
	bonus.frame:setVisible ( false )
	
	bonus.sandBG = graphics.createSprite ()
	bonus.sandBG:setDeck ( res.tropics.bonus )
	bonus.sandBG:setIndex ( 2 )
	bonus.sandBG:setLayer ( bonusLayer )
	bonus.sandBG:setVisible ( false )
	
	bonus.crabWords = graphics.createSprite ()
	bonus.crabWords:setDeck ( res.tropics.bonus )
	bonus.crabWords:setIndex ( 7 )
	bonus.crabWords:setLayer ( bonusLayer )
	bonus.crabWords:setVisible ( false )
	
	-- waves
	bonus.waves = graphics.createSprite ()
	flash.decorateAsFlashAnim ( bonus.waves )
	bonus.waves:setDeck ( bonus.waves:loadFlashFlipbookAnim ( { filename = TROPICS_MOUNT_POINT .. "/resources/WS_TropicalFlipbookBonus.fla.lua", startFrame = 1, endFrame = 13 }))
	bonus.waves:setAnimSpan ( 1, 13 )
	bonus.waves:setLayer ( bonusLayer )
	bonus.waves:setVisible ( false )
	bonus.waves:addLoc ( 0, 14 )
	bonus.waves:setSpeed ( .75 )
	
	local waveThread = MOAIThread.new ()
	waveThread:run (
		function ()
			
			while true do
				
				bonus.waves:start ()
				util.waitSeconds ( .5 )
				bonus.waves:seekColor ( 0, 0, 0, .1, 1 )
				repeat coroutine.yield () until not bonus.waves:isBusy ()
				bonus.waves:setVisible ( false )
				util.waitSeconds ( 1 )
				bonus.waves:setVisible ( true )
				bonus.waves:setColor ( 1, 1, 1, 1 )
			end
		end
	)
	
	oh = soundmgr.createSound ( TROPICS_MOUNT_POINT .. "/resources/sound/tropical_crab.wav" )
	scuttle = soundmgr.createSound ( TROPICS_MOUNT_POINT .. "/resources/sound/tropical_crabmove.wav" )
	
	bonusMusic = soundmgr.createSound ( TROPICS_MOUNT_POINT .. "/resources/sound/tropical_bonus.ogg" )
	bonusMusic:setLooping ( true )
	
	-- buckets
	bonus.buckets = createBuckets ( )
end

----------------------------------------------------------------
bonus.onLoseFocus = function ( self )
	
end

----------------------------------------------------------------
bonus.onUnload = function ( self )
	
	for i, layerSet in ipairs ( self.layerTable ) do
		
		for j, layer in ipairs ( layerSet ) do
		
			layer = nil
		end
	end
	
	self.layerTable = nil
	mainLayer = nil

end

----------------------------------------------------------------
bonus.onUpdate = function ( self )

	if state == DONE then
		
		bonusMusic:stop ()
		returndata.done = true
		statemgr.pop ()
	end	

end

return bonus