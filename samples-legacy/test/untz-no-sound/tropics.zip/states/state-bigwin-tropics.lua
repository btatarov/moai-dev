--==============================================================
-- Copyright (c) 2010-2011 Zipline Games, Inc. 
-- All Rights Reserved. 
-- http://getmoai.com
--==============================================================

local win = {}
statemgr.makePopup ( win )

win.layerTable = nil
local mainLayer = nil

local initX, initY = 0, 1280
local SLIDE_TIME = .2

local particles = nil

local shade = nil
local winScreen = nil
local winText = nil
local particles = nil
local particleAnim = nil
local particleProp = nil
local animStarted = false

local music, whale

----------------------------------------------------------------
-- local functions
----------------------------------------------------------------
local function showAnim ()
	
	local thread = MOAIThread.new ()
	thread:run (
		
		function ()
		
			MOAIThread.blockOnAction ( shade:seekColor ( 0, 0, 0, .5, SLIDE_TIME, MOAIEaseType.LINEAR ))
			
			music:play ()
			
			winScreen:setVisible ( true )
			winText:setVisible ( true )
			winScreen:start ()
			winText:start ()
			animStarted = true
			
			particleAnim:start ()
			util.waitSeconds ( .5 )
			whale:play ()
			particles:start ()
			util.waitSeconds ( 1.33 )
			particles:stop ( )
			
			repeat coroutine.yield () until not winScreen:isBusy ()
			particleAnim:stop ()			
			util.waitSeconds ( 1.5 )
			
			statemgr.pop ()
		end
	)
end

----------------------------------------------------------------
-- state functions
----------------------------------------------------------------
win.onFocus = function ( self )

	animStarted = false
	showAnim ()
end

----------------------------------------------------------------
win.onInput = function ( self )

end

----------------------------------------------------------------
win.onLoad = function ( self )

	self.layerTable = {}
	mainLayer = MOAILayer2D.new ()
	mainLayer:setViewport ( viewport )
	self.layerTable [ 1 ] = {  mainLayer }

	local tex = MOAITexture.new ()
	tex:load ( "resources/white.png" )
	tex:setWrap ( true )
	
	local gfxQuad = MOAIGfxQuad2D.new ()
	gfxQuad:setTexture ( tex )
	gfxQuad:setRect ( -640, -480, 640, 480 )
	
	shade = graphics.createSprite ()
	shade:setDeck ( gfxQuad )
	shade:setLayer ( mainLayer )
	shade:setColor ( 0, 0, 0, 0 )
	shade:setPriority ( 1 )
	
	winScreen = graphics.createSprite ()
	flash.decorateAsFlashAnim ( winScreen )
	winScreen:setDeck ( winScreen:loadFlashFlipbookAnim ( { filename = TROPICS_MOUNT_POINT .. "/resources/WS_TropicalFlipbook.fla.lua", startFrame = 47, endFrame = 84 }))
	winScreen:setAnimSpan ( 1, 38 ) 
	winScreen:setLayer ( mainLayer )
	winScreen:setPriority ( 4 )	
	winScreen:setVisible ( false )
	
	winText = graphics.createSprite ()
	flash.decorateAsFlashAnim ( winText )
	winText:setDeck ( winText:loadFlashFlipbookAnim ( { filename = TROPICS_MOUNT_POINT .. "/resources/WS_TropicalFlipbook.fla.lua", startFrame = 86, endFrame = 123 }))
	winText:setAnimSpan ( 1, 38 )
	winText:setLayer ( mainLayer )
	winText:setPriority ( 2 )
	winText:setVisible ( false )
	
	particleProp = MOAIProp2D.new ()
	
	particles = util.doFile ( TROPICS_MOUNT_POINT .. "/particles/particles-bubble-burst.lua" )
	particles:setLayer ( mainLayer )
	particles:setPriority ( 3 )
	particles:setParent ( particleProp )

	local curveX = MOAIAnimCurve.new ()
	curveX:reserveKeys ( 6 )
	curveX:setKey ( 1, 0.00, 785 - 480, MOAIEaseType.LINEAR )
	curveX:setKey ( 2, 0.50, 785 - 480, MOAIEaseType.LINEAR )
	curveX:setKey ( 3, 0.83, 652 - 480, MOAIEaseType.LINEAR )
	curveX:setKey ( 4, 1.16, 463 - 480, MOAIEaseType.LINEAR )
	curveX:setKey ( 5, 1.49, 281 - 480, MOAIEaseType.LINEAR )
	curveX:setKey ( 6, 1.83, 135 - 480, MOAIEaseType.LINEAR )
	
	local curveY = MOAIAnimCurve.new ()
	curveY:reserveKeys ( 6 )
	curveY:setKey ( 1, 0.00, 300 - 226, MOAIEaseType.LINEAR )
	curveY:setKey ( 2, 0.50, 300 - 226, MOAIEaseType.LINEAR )
	curveY:setKey ( 3, 0.83, 300 - 381, MOAIEaseType.LINEAR )
	curveY:setKey ( 4, 1.16, 300 - 416, MOAIEaseType.LINEAR )
	curveY:setKey ( 5, 1.49, 300 - 336, MOAIEaseType.LINEAR )
	curveY:setKey ( 6, 1.83, 300 - 145, MOAIEaseType.LINEAR )
	
	
	particleAnim = MOAIAnim.new ()
	particleAnim:reserveLinks ( 2 )
	particleAnim:setLink ( 1, curveX, particleProp, MOAITransform.ATTR_X_LOC )
	particleAnim:setLink ( 2, curveY, particleProp, MOAITransform.ATTR_Y_LOC )
	
	music = soundmgr.createSound ( TROPICS_MOUNT_POINT .. "/resources/sound/tropical_bigwin.ogg" )
	whale = soundmgr.createSound ( TROPICS_MOUNT_POINT .. "/resources/sound/tropical_whale.wav" )
end

----------------------------------------------------------------
win.onLoseFocus = function ( self )
	
	winScreen:stop ()
	winScreen:setVisible ( false )
	MOAIThread.blockOnAction ( shade:seekColor ( 0, 0, 0, 0, SLIDE_TIME, MOAIEaseType.LINEAR ))
end

----------------------------------------------------------------
win.onUnload = function ( self )
	
	for i, layerSet in ipairs ( self.layerTable ) do
		
		for j, layer in ipairs ( layerSet ) do
		
			layer = nil
		end
	end
	
	self.layerTable = nil
	mainLayer = nil

end

----------------------------------------------------------------
win.onUpdate = function ( self )

end

return win