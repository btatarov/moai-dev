--==============================================================
-- Copyright (c) 2010-2011 Zipline Games, Inc. 
-- All Rights Reserved. 
-- http://getmoai.com
--==============================================================

local tropics = {}
tropics.layerTable = nil
local mainLayer = nil

local MAX_LINES = 24
local curLineIdx = 1
local curBetIdx = 1

local prevUpdateLine

local bonusOn = false
local bonusIndexes = {
	[ 0 ] = 11,
	[ 1 ] = 12,
	[ 2 ] = 13,
	[ 3 ] = 14,
	[ 4 ] = 15,
	[ 5 ] = 16,
	[ 6 ] = 17,
	[ 7 ] = 18,
	[ 8 ] = 19,
	[ 9 ] = 20,
	[ 10 ] = 21
}

local showingWins = false
local coinsAnimating = false
local giveXP = true
local blockBetDisplay = false

local triggerMedWin = false
local triggerBigWin = false
local triggerMaxWin = false
local triggerBonus = false
local triggerXp = false

local continuousSpin = false

local sessionStats = {
	spins = 0,
	startTime = 0
}

local bonusdata = { bet = 0, freespins = 0, coins = 0, multiplier = 0, done = false }

----------------------------------------------------------------
-- local functions
----------------------------------------------------------------
local function countDownCoins ( spendings, step )
	
	local thread = MOAIThread.new ()
	thread:run (
		
		function ()
			
			local coinCounter = gamestate.coins
			local coinsToLose = spendings
			gamestate.coins = gamestate.coins - spendings
		
			coinsAnimating = true
			while coinsToLose > 0 do
			
				if coinsToLose >= step then
					coinCounter = coinCounter - step
					coinsToLose = coinsToLose - step
				else
					coinCounter = coinCounter - coinsToLose
					coinsToLose = coinsToLose - coinsToLose
				end
				
				tropics.coinText:setText ( util.addCommas ( coinCounter ))
				util.waitSeconds ( .07 )
			end	
			
			coinsAnimating = false
			tropics.coinText:setText ( util.addCommas ( gamestate.coins ))
		end
	)
end

----------------------------------------------------------------
local function countUpCoins ( winnings, step )
	
	local thread = MOAIThread.new ()
	thread:run (
		
		function ()
			
			local coinCounter = gamestate.coins
			local coinsToPay = winnings
			gamestate.coins = gamestate.coins + winnings
		
			coinsAnimating = true
			while coinsToPay > 0 do
			
				tropics.coinSound:play ()
				
				if coinsToPay >= step then
					coinCounter = coinCounter + step
					coinsToPay = coinsToPay - step
				else
					coinCounter = coinCounter + coinsToPay
					coinsToPay = coinsToPay - coinsToPay
				end
				
				tropics.coinText:setText ( util.addCommas ( coinCounter ))
				util.waitSeconds ( .07 )
			end
			
			coinsAnimating = false
			tropics.coinText:setText ( util.addCommas ( gamestate.coins ))
		end
	)
end

----------------------------------------------------------------
local function zeroBonus ()
	
	gamestate.bonusMeter.tropics = 0
	
	-- call up the amount for a full bonus meter from the cloud here
	local fromCloud = nil
	
	gamestate.bonusMax.tropics = ( gamestate.nextBonusMax ) and gamestate.nextBonusMax.tropics or 45
end

----------------------------------------------------------------
local function updateBonusBar ()

	if bonusOn then return end
	
	local bonusIndex = math.floor ( gamestate.bonusMeter.tropics / ( gamestate.bonusMax.tropics / 10 ) )
	
	tropics.bonusMeter:setIndex ( bonusIndexes [ bonusIndex ] )
	
	if gamestate.bonusMeter.tropics == gamestate.bonusMax.tropics then 
		triggerBonus = true
		zeroBonus ()
		bonusOn = true
		return
	end
	
end

----------------------------------------------------------------
local delayTrigger = false
local function updateTotalWin ( payout, bonusValue )
	
	if bonusValue == tropics.machine.maxJackpot then
		-- show max jackpot
		delayTrigger = true
		triggerMaxWin = true
	elseif bonusValue == tropics.machine.largeJackpot then
		-- show large jackpot
		delayTrigger = true
		triggerBigWin = true		
	elseif bonusValue == tropics.machine.medJackpot then
		-- show med jackpot
		delayTrigger = true
		triggerMedWin = true
	end
	
	local thread = MOAIThread.new ()
	thread:run (
		
		function ()
			
			if delayTrigger then repeat coroutine.yield () until not delayTrigger end
			countUpCoins ( payout, math.ceil ( payout / ( 1.5 / .07 )))
			--util.waitSeconds ( 1.0 )
			showingWins = false
			updateBonusBar ()
		end
	)
	
	local thread2 = MOAIThread.new ()
	thread2:run (
		
		function ()
			
			blockBetDisplay = true
			if delayTrigger then repeat coroutine.yield () until not delayTrigger end
			tropics.totalBet:setText ( "" )
			tropics.winsAnim:setAnimSpan ( 1, 9 )
			tropics.winsAnim:setColor ( 1, 1, 1, 1 )
			tropics.totalWins:setColor ( 0, 0, 0, 0 )
			MOAIThread.blockOnAction ( tropics.winsAnim:start () )
			tropics.totalBet:setRot ( 0, 0, -2 )
			tropics.totalBet:setText ( util.addCommas ( payout ) )
			util.waitSeconds ( 2 )
			tropics.totalBet:setText ( "" )
			tropics.winsAnim:setAnimSpan ( 10, 18 )
			MOAIThread.blockOnAction ( tropics.winsAnim:start () )
			tropics.winsAnim:setColor ( 0, 0, 0, 0 )
			tropics.totalWins:setColor ( 1, 1, 1, 1 )
			tropics.winsAnim:setAnimFrame ( 1 )
			tropics.totalBet:setText ( "" )
			
			-- done now, reset bet display
			tropics.totalBet:setRot ( 0, 0, 2 )
			tropics.totalBet:setText ( util.addCommas ( gamestate.validBets [ curBetIdx ] * curLineIdx ) )
			blockBetDisplay = false
		end
	)
	
end

----------------------------------------------------------------
local function updateXpBar ()
	
	-- top: ( -386, 123 )
	-- bottom: ( -369, -258 )
	local deltaX = math.abs ( -386 - -369 )
	local deltaY = math.abs ( 123 - -258 )
	
	if gamestate.level > #levelTable then
		tropics.levelNotch:setLoc ( -369, -258 )	-- bottom
		tropics.levelMeter:setScl ( 1, 0 )
		return
	end
	
	local percentage = gamestate.xpThisLevel / gamestate.xpToNextLevel
	local x, y = -369 - ( percentage * deltaX ), -258 + ( percentage * deltaY )
	tropics.levelNotch:setLoc ( x, y )
	
	-- weirdness, we only want 502 pixels of th 512 for the meter
	local scaleY = ( percentage * 502 ) / 512
	tropics.levelMeter:setScl ( 1, scaleY )
	
	tropics.levelText:setText ( tostring ( gamestate.level ) )
end

----------------------------------------------------------------
local function levelingUp ()

	repeat
	
		gamestate.level = gamestate.level + 1
		levelTable.giveAwards ( gamestate.level )		
	until gamestate.xp < levelTable [ gamestate.level ].nextLevel or gamestate.level > #levelTable
	
	gamestate.xpThisLevel = gamestate.xp - levelTable [ gamestate.level - 1 ].nextLevel
	
	triggerXp = true
	
	if gamestate.level <= #levelTable then
		gamestate.xpToNextLevel = levelTable [ gamestate.level ].nextLevel - levelTable [ gamestate.level - 1 ].nextLevel
	else
		gamestate.xpToNextLevel = 0
	end
end

----------------------------------------------------------------
local spinThread = MOAIThread.new ()
local function spinFunc ()

	if giveXP then
		local xp_gain = gamestate.validBets [ curBetIdx ] * curLineIdx
		gamestate.xp = gamestate.xp + xp_gain
		gamestate.xpThisLevel = gamestate.xpThisLevel + xp_gain
	end
			
	local bet = gamestate.validBets [ curBetIdx ] * curLineIdx
	countDownCoins ( bet, math.ceil ( bet / ( 1.5 / .07 )))
	--totalWin:setText ( tostring ( 0 ))

	local payout, bonusValue, linesWon
	sessionStats.spins = sessionStats.spins + 1
	-- print ( "spin1" )
	payout, bonusValue, linesWon = tropics.machine:spin ( gamestate.validBets [ curBetIdx ] )
	-- print ( "spin5" )
	if bonusValue > 1 then eventmgr.recordJackpot ( bonusValue, "tropics" ) end
	eventmgr.recordSpin ( linesWon, curLineIdx, payout, gamestate.validBets [ curBetIdx ] )

	while tropics.machine:isShowingWins () do
		coroutine.yield ()
	end
	
	if payout and payout > 0 then
		gamestate.bonusMeter.tropics = gamestate.bonusMeter.tropics + 1
		updateTotalWin ( payout, bonusValue )  
	else
		showingWins = false
		updateBonusBar ()
	end
	
	if gamestate.level <= #levelTable and gamestate.xp >= levelTable [ gamestate.level ].nextLevel then
		levelingUp ()
	else	
		updateXpBar ()
	end
	
	savefile.saveGame ( gamestate, "gamestate.lua" )	
end

----------------------------------------------------------------
local function setLightIndex ( light, num )

	light:setIndex ( num + 25 )
	
end

----------------------------------------------------------------
local function determineMaxBet ()
	local topBetIndex, topLines = 1, 1
	
	if gamestate.coins <= 0 then return false end
	
	if gamestate.coins > gamestate.payLines then topLines = gamestate.payLines
	else for i = 1, gamestate.payLines do if gamestate.coins >= i then topLines = i end end
	end
	
	for i = 1, #gamestate.validBets do
		if gamestate.validBets [ i ] * topLines <= gamestate.coins then topBetIndex = i end
	end
	
	curBetIdx = topBetIndex
	curLineIdx = topLines
	
	return true
end

----------------------------------------------------------------
local function updateTotalBet ()
	
	if blockBetDisplay then return end
	
	tropics.totalBet:setText ( util.addCommas ( gamestate.validBets [ curBetIdx ] * curLineIdx ) )
end

----------------------------------------------------------------
local function updateBetText ()

	tropics.betText:setText ( util.addCommas ( gamestate.validBets [ curBetIdx ] ) )
	updateTotalBet ()
end

----------------------------------------------------------------
local function updateLineText ()

	tropics.lineText:setText ( tostring ( curLineIdx ) )	
	updateTotalBet ()
	
	if prevUpdateLine then prevUpdateLine:stop () end
	
	local thread = MOAIThread.new ()
	thread:run ( 
		function ()	
	
			local cur = curLineIdx
			for i = 1, MAX_LINES do
			
				tropics.theLines [ i ].light:setVisible ( false )
				tropics.theLines [ i ]:setVisible ( false )
			end
			
			
			for i = 1, cur do
			
				tropics.theLines [ i ].light:setVisible ( true )
				tropics.theLines [ i ]:setVisible ( true )
			end			
			
			util.waitSeconds ( 1 )
			
				
			for i = 1, cur do
			
				tropics.theLines [ i ]:setVisible ( false )
			end			
		end
	)
	prevUpdateLine = thread
	
	tropics.machine:setActiveLines ( curLineIdx )
end

----------------------------------------------------------------
-- state functions
----------------------------------------------------------------
tropics.onFocus = function ( self )
	
	delayTrigger = false
	tropics.frondAnim:start ()
	tropics.palmAnim:start ()
	tropics.bananaAnim:start ()
	tropics.leaf3Anim:start ()
	tropics.leaf2Anim:start ()
	tropics.leaf1Anim:start ()
	tropics.ambientNoise:play ()
	tropics.coinText:setText ( util.addCommas ( gamestate.coins ) )
	if not gamestate.bonusMeter.tropics then zeroBonus () end
	updateBonusBar ()
	updateXpBar ()
	updateTotalBet ()

	if bonusdata.freespins > 0 then
		freeSpins = freeSpins + bonusdata.freespins
		bonusdata.freespins = 0
		bonusdata.done = false
	end
	
	if bonusdata.coins > 0 then
		countUpCoins ( bonusdata.coins, math.ceil ( bonusdata.coins / ( 1.5 / .07 )))
		bonusdata.coins = 0
	end
	
	if bonusdata.multiplier > 0 then
		local multiplierBonus = gamestate.validBets [ curBetIdx ] * curLineIdx * bonusdata.multiplier
		countUpCoins ( multiplierBonus, math.ceil ( multiplierBonus / ( 1.5 / .07 )))
		bonusdata.multiplier = 0
	end
		
	if bonusdata.done then
		bonusOn = false
		zeroBonus ()
		updateBonusBar ()
		bonusdata.done = false
		savefile.saveGame ( gamestate, "gamestate.lua" )
	end
end

----------------------------------------------------------------
tropics.onInput = function ( self )

	local x, y = inputmgr.getTouch ()
	local wldX, wldY = mainLayer:wndToWorld ( x, y )
	
	if inputmgr.up () and not tropics.machine:isSpinning () and not tropics.machine:isSkipping () and showingWins then
		
		tropics.machine:doSkip ( true )
	end
	
	if tropics.machine:isSpinning () then return end
	
	if inputmgr.up () then
		
		continuousSpin = false
		
		if tropics.betButton:inside ( wldX, wldY ) then
			
			tropics.buttonSound2:play ()
			curBetIdx = ( curBetIdx % #gamestate.validBets ) + 1
			updateBetText ()
			return
		end
		
		if tropics.lineButton:inside ( wldX, wldY ) then
			
			tropics.buttonSound2:play ()
			curLineIdx = ( curLineIdx % gamestate.payLines ) + 1
			updateLineText ()
			return
		end
		
		if tropics.spinButton:inside ( wldX, wldY ) and not showingWins then
			
			local thisBet = gamestate.validBets [ curBetIdx ] * curLineIdx

			if thisBet <= gamestate.coins then

				if not tropics.machine:isSpinning () then

					tropics.buttonSound1:play ()
					spinThread:stop ()
					showingWins = true
					if DEMO_MODE then DEMO_ACTIVATED = false end
					spinThread:run ( spinFunc )
					savefile.saveGame ( gamestate, "gamestate.lua" )
				end
			else
				-- inform the player of insufficient funds, point to coin store

				statemgr.push ( "states/state-notify-popup.lua", localizedText.brassMain.notEnough, 33, localizedText.brassMain.purchase, localizedText.brassMain.get, function ()
						statemgr.pop ()
						statemgr.push ( "states/state-store-popup.lua", storeTable )
					end )
			end
			return
		end
		
		if tropics.maxButton:inside ( wldX, wldY ) and not showingWins then
			curLineIdx = gamestate.payLines
			curBetIdx = #gamestate.validBets
			updateLineText ()
			updateBetText ()

			local thisBet = gamestate.validBets [ curBetIdx ] * curLineIdx

			if thisBet <= gamestate.coins then

				if not tropics.machine:isSpinning () then

					tropics.buttonSound1:play ()
					spinThread:stop ()
					showingWins = true
					if DEMO_MODE then DEMO_ACTIVATED = false end
					spinThread:run ( spinFunc )
					savefile.saveGame ( gamestate, "gamestate.lua" )
				end				
			else
				if determineMaxBet () then

					if not tropics.machine:isSpinning () then

						updateLineText ()
						updateBetText ()					
						spinThread:stop ()
						showingWins = true
						if DEMO_MODE then DEMO_ACTIVATED = false end
						spinThread:run ( spinFunc )
						savefile.saveGame ( gamestate, "gamestate.lua" )
					end				

				else
					-- inform the player of insufficient funds, point to coin store

					statemgr.push ( "states/state-notify-popup.lua", localizedText.brassMain.notEnough, 33, localizedText.brassMain.purchase, localizedText.brassMain.get, function ()
							statemgr.pop ()
							statemgr.push ( "states/state-store-popup.lua", storeTable )
						end )
				end
			end
			return
		end
		
		if tropics.menuButton:inside ( wldX, wldY ) then
			print "menu"
			tropics.buttonSound2:play ()
			if DEBUG_MENUS then


				statemgr.push ( "states/state-settings-diner-popup.lua", 
					{ 
						[ 2 ] = { text = "Main Menu", callback = function () statemgr.pop () statemgr.pop () end },
						[ 1 ] = { text = "Back to Game", callback = function () statemgr.pop () end },
								[ 3 ] = { text = "Continuous Spin",
									callback = function ( textbox )
										continuousSpin = true
										statemgr.pop ()
									end
								},
						[ 4 ] = { text = "Manually Save",
							callback = function ( textbox )
								savefile.saveGame ( gamestate, "gamestate.lua" )
								textbox:setText ( "Gamestate saved." )						
							end
						}	,
							[ 5 ] = { text = "Bonus Game", 
							 	callback = function ( textbox ) 

							 		triggerBonus = true
							 		statemgr.pop ()
							 	end
							  },
							[ 6 ] = { text = "Small jackpot", 
							 	callback = function ( textbox )

							 		triggerMedWin = true
							 		statemgr.pop ()
							 	end
							 },
							[ 7 ] = { text = "Medium jackpot", 
							  	callback = function ( textbox )

							  		triggerBigWin = true
							  		statemgr.pop ()
							  	end
							 },
							[ 8 ] = { text = "Large jackpot", 
							   	callback = function ( textbox )

							   		triggerMaxWin = true
							   		statemgr.pop ()
							   	end
							 }
						})

			else

				statemgr.pop ()
			end
			return
		end
		
		if tropics.storeButton:inside ( wldX, wldY ) then
			print "store"
			tropics.buttonSound2:play ()
			statemgr.push ( "states/state-store-popup.lua", storeTable )
			return
		end
		
		if tropics.paytableButton:inside ( wldX, wldY ) then
			print "pay table"
			tropics.buttonRustle:play ()
			statemgr.push ( "states/state-paytable-popup.lua", tropics.machine:getPayTable (), res.tropics.icons, 61, 68, 69, { r = 1, g = 1, b = 1, a = 1 }, res.tropics.main, -50, 520, 128, 148 )
			return
		end
	end
end

----------------------------------------------------------------
tropics.onLoad = function ( self )

	self.layerTable = {}
	mainLayer = MOAILayer2D.new ()
	mainLayer:setViewport ( viewport )
	self.layerTable [ 1 ] = { mainLayer }
	
	local reelBG = graphics.createSprite ()
	reelBG:setDeck ( res.tropics.main2 )
	reelBG:setIndex ( 1 )
	reelBG:setLayer ( mainLayer )
	reelBG:setPriority ( 1 )
	
	local frame = graphics.createSprite ()
	frame:setDeck ( res.tropics.main2 )
	frame:setIndex ( 2 )
	frame:setLayer ( mainLayer )
	frame:setPriority ( 4 )
	
	tropics.shimmer = graphics.createSprite ()
	flash.decorateAsFlashAnim ( tropics.shimmer )
	tropics.shimmer:setDeck ( tropics.shimmer:loadFlashFlipbookAnim ( { filename = TROPICS_MOUNT_POINT .. "/resources/WS_TropicalFlipbook2.fla.lua", startFrame = 19, endFrame = 29 } ) )
	tropics.shimmer:setLayer ( mainLayer )
	tropics.shimmer:setPriority ( 4 )
	tropics.shimmer:setAnimSpan ( 1, 10 )
	tropics.shimmer:setLoc ( 0, 0 )
	tropics.shimmer:setColor ( .1, .1, .1, 0 )
	tropics.shimmer:setMode ( MOAITimer.LOOP )
	tropics.shimmer:setSpeed ( .5 )
	tropics.shimmer:start ()
	
	-- tropics.shimmer2 = graphics.createSprite ()
	-- flash.decorateAsFlashAnim ( tropics.shimmer2 )
	-- tropics.shimmer2:setDeck ( tropics.shimmer2:loadFlashFlipbookAnim ( { filename = TROPICS_MOUNT_POINT .. "/resources/WS_TropicalFlipbook2.fla.lua", startFrame = 19, endFrame = 29 } ) )
	-- tropics.shimmer2:setLayer ( mainLayer )
	-- tropics.shimmer2:setPriority ( 4 )
	-- tropics.shimmer2:setAnimSpan ( 1, 10 )
	-- tropics.shimmer2:setLoc ( 0, 0 )
	-- tropics.shimmer2:setScl ( -1, 1 )
	-- tropics.shimmer2:setColor ( .25, .25, .25, 0 )
	-- tropics.shimmer2:setMode ( MOAITimer.LOOP )
	-- tropics.shimmer2:setSpeed ( .5 )
	-- tropics.shimmer2:start ()
	
	local surfboard = graphics.createSprite ()
	surfboard:setDeck ( res.tropics.main )
	surfboard:setIndex ( 57 )
	surfboard:setLayer ( mainLayer )
	surfboard:setPriority ( 8 )	
	
	local lineNumbers = graphics.createSprite ()
	lineNumbers:setDeck ( res.tropics.main )
	lineNumbers:setIndex ( 59 )
	lineNumbers:setLayer ( mainLayer )
	lineNumbers:setPriority ( 8 )
	
	local bananaTree = graphics.createSprite ()
	bananaTree:setDeck ( res.tropics.main )
	bananaTree:setIndex ( 51 )
	bananaTree:setLayer ( mainLayer )
	bananaTree:setLoc ( -390, -380 )
	bananaTree:setPriority ( 5 )
	
	local bananaCurve = MOAIAnimCurve.new ()
	bananaCurve:reserveKeys ( 3 )
	bananaCurve:setKey ( 1, 0, 0, MOAIEaseType.SOFT_SMOOTH )
	bananaCurve:setKey ( 2, 4, -1.5, MOAIEaseType.SOFT_SMOOTH )
	bananaCurve:setKey ( 3, 8, 0, MOAIEaseType.SOFT_SMOOTH )
	
	tropics.bananaAnim = MOAIAnim.new ()
	tropics.bananaAnim:reserveLinks ( 1 )
	tropics.bananaAnim:setLink ( 1, bananaCurve, bananaTree, MOAIProp2D.ATTR_Z_ROT )
	tropics.bananaAnim:setMode ( MOAITimer.LOOP )
	
	-- bet button
	tropics.betButton = graphics.createSpriteButton ()
	tropics.betButton:setDeck ( res.tropics.main )
	tropics.betButton:setIndex ( 3 )
	tropics.betButton:setLayer ( mainLayer )
	tropics.betButton:setPriority ( 9 )

	-- line button
	tropics.lineButton = graphics.createSpriteButton ()
	tropics.lineButton:setDeck ( res.tropics.main )
	tropics.lineButton:setIndex ( 4 )
	tropics.lineButton:setLayer ( mainLayer )
	tropics.lineButton:setPriority ( 10 )
	
	-- total display	
	tropics.totalWins = graphics.createSprite ()
	tropics.totalWins:setDeck ( res.tropics.main )
	tropics.totalWins:setIndex ( 58 )
	tropics.totalWins:setLayer ( mainLayer )
	tropics.totalWins:setPriority ( 11 )
	
	tropics.winsAnim = graphics.createSprite ()
	flash.decorateAsFlashAnim ( tropics.winsAnim )
	tropics.winsAnim:setDeck ( tropics.winsAnim:loadFlashFlipbookAnim ( { filename = TROPICS_MOUNT_POINT .. "/resources/WS_TropicalFlipbook2.fla.lua", startFrame = 1, endFrame = 18 } ) )
	tropics.winsAnim:setLayer ( mainLayer )
	tropics.winsAnim:setPriority ( 11 )
	tropics.winsAnim:setAnimSpan ( 1, 9 )
	tropics.winsAnim:setLoc ( 4, -232 )
	tropics.winsAnim:setMode ( MOAITimer.NORMAL )
	tropics.winsAnim:setColor ( 0, 0, 0, 0 )
	
	-- spin button
	local spinGraphic = graphics.createSprite ()
	spinGraphic:setDeck ( res.tropics.main )
	spinGraphic:setIndex ( 5 )
	spinGraphic:setLayer ( mainLayer )
	spinGraphic:setRot ( 0 )
	spinGraphic:setScl ( 1, 1 )
	spinGraphic:setLoc ( 756 - 480, 320 - 561 )
	spinGraphic:setPriority ( 9 )

	tropics.spinButton = graphics.createSpriteButton2 ()
	tropics.spinButton:setFrame ( 221, -184, 336, -297 )
	tropics.spinButton.onPress = function ()
		spinGraphic:setRot ( 10 )
		spinGraphic:setScl ( .9, .9 )
	end
	tropics.spinButton.onRelease = function ()
		spinGraphic:setRot ( 0 )
		spinGraphic:setScl ( 1, 1 )
	end

	-- max bet 
	local maxGraphic = graphics.createSprite ()
	maxGraphic:setDeck ( res.tropics.main )
	maxGraphic:setIndex ( 6 )
	maxGraphic:setLayer ( mainLayer )
	maxGraphic:setLoc ( 638 - 480, 320 - 562 )
	maxGraphic:setPriority ( 10 )
	maxGraphic:setRot ( 0 )
	maxGraphic:setScl ( 1, 1 )
			
	tropics.maxButton = graphics.createSpriteButton2 ()
	tropics.maxButton:setFrame ( 97, -177, 216, -307 )
	tropics.maxButton.onPress = function ()
		maxGraphic:setRot ( -10 )
		maxGraphic:setScl ( .9, .9 )
	end
	tropics.maxButton.onRelease = function ()
		maxGraphic:setRot ( 0 )
		maxGraphic:setScl ( 1, 1 )
	end
			
	-- store button
	local storeGraphic = graphics.createSprite ()
	storeGraphic:setDeck ( res.tropics.main )
	storeGraphic:setIndex ( 8 )
	storeGraphic:setLayer ( mainLayer )
	storeGraphic:setPriority ( 7 )
	storeGraphic:setColor ( 1, 1, 1, 1 )
		
	tropics.storeButton = graphics.createSpriteButton2 ()
	tropics.storeButton:setFrame ( -351, 319, -185, 193 )
	tropics.storeButton.onPress = function ()
		storeGraphic:setColor ( .95, .95, .95, 1 )
	end
	tropics.storeButton.onRelease = function ()	
		storeGraphic:setColor ( 1, 1, 1, 1 )
	end
	
	local coin = graphics.createSprite ()
	coin:setDeck ( res.tropics.main )
	coin:setIndex ( 9 )
	coin:setLayer ( mainLayer )
	coin:setPriority ( 5 )
		
	-- menu button 
	local menuGraphic = graphics.createSprite ()
	menuGraphic:setDeck ( res.tropics.main )
	menuGraphic:setIndex ( 7 )
	menuGraphic:setLayer ( mainLayer )
	menuGraphic:setLoc ( 84 - 480, 320 - 86 )
	menuGraphic:setPriority ( 7 )
	menuGraphic:setScl ( 1, 1 )
	
	tropics.menuButton = graphics.createSpriteButton2 ()
	tropics.menuButton:setFrame ( -443, 318, -354, 153 )
	tropics.menuButton.onPress = function ()
		menuGraphic:setScl ( .9, .9 )
	end
	tropics.menuButton.onRelease = function ()
		menuGraphic:setScl ( 1, 1 )
	end
	
	-- paytable button 
	local frond = graphics.createSprite ()
	frond:setDeck ( res.tropics.main )
	frond:setIndex ( 52 )
	frond:setLayer ( mainLayer )
	frond:setLoc ( -620, 385 )
	frond:setPriority ( 5 )
	
	tropics.paytableButton = graphics.createSpriteButton ()
	tropics.paytableButton:setDeck ( res.tropics.main )
	tropics.paytableButton:setIndex ( 10 )
	tropics.paytableButton:setLayer ( mainLayer )
	tropics.paytableButton:setParent ( frond )
	tropics.paytableButton:setPriority ( 10 )
	
	local frondCurve = MOAIAnimCurve.new ()
	frondCurve:reserveKeys ( 3 )
	frondCurve:setKey ( 1, 0, 0, MOAIEaseType.SOFT_SMOOTH )
	frondCurve:setKey ( 2, 5, -0.5, MOAIEaseType.SOFT_SMOOTH )
	frondCurve:setKey ( 3, 10, 0, MOAIEaseType.SOFT_SMOOTH )
	
	tropics.frondAnim = MOAIAnim.new ()
	tropics.frondAnim:reserveLinks ( 1 )
	tropics.frondAnim:setLink ( 1, frondCurve, frond, MOAIProp2D.ATTR_Z_ROT )
	tropics.frondAnim:setMode ( MOAITimer.LOOP )
	
	local palmleave = graphics.createSprite ()
	palmleave:setDeck ( res.tropics.main )
	palmleave:setIndex ( 53 )
	palmleave:setLayer ( mainLayer )
	palmleave:setLoc ( -600, 240 )
	palmleave:setPriority ( 6 )
	
	local palmCurve = MOAIAnimCurve.new ()
	palmCurve:reserveKeys ( 3 )
	palmCurve:setKey ( 1, 0, 0, MOAIEaseType.SOFT_SMOOTH )
	palmCurve:setKey ( 2, 3, 1.5, MOAIEaseType.SOFT_SMOOTH )
	palmCurve:setKey ( 3, 6, 0, MOAIEaseType.SOFT_SMOOTH )
	
	tropics.palmAnim = MOAIAnim.new ()
	tropics.palmAnim:reserveLinks ( 1 )
	tropics.palmAnim:setLink ( 1, palmCurve, palmleave, MOAIProp2D.ATTR_Z_ROT )
	tropics.palmAnim:setMode ( MOAITimer.LOOP )
	
	local rightLeaf3 = graphics.createSprite ()
	rightLeaf3:setDeck ( res.tropics.main )
	rightLeaf3:setIndex ( 56 )
	rightLeaf3:setLayer ( mainLayer )
	rightLeaf3:setLoc ( 490, -270 )
	rightLeaf3:setPriority ( 6 )
		
	local rightLeaf2 = graphics.createSprite ()
	rightLeaf2:setDeck ( res.tropics.main )
	rightLeaf2:setIndex ( 55 )
	rightLeaf2:setLayer ( mainLayer )
	rightLeaf2:setLoc ( 445, -360 )
	rightLeaf2:setPriority ( 6 )
		
	local rightLeaf1 = graphics.createSprite ()
	rightLeaf1:setDeck ( res.tropics.main )
	rightLeaf1:setIndex ( 54 )
	rightLeaf1:setLayer ( mainLayer )
	rightLeaf1:setLoc ( 360, -370 )
	rightLeaf1:setPriority ( 6 )
	
	local leafCurve = MOAIAnimCurve.new ()
	leafCurve:reserveKeys ( 3 )
	leafCurve:setKey ( 1, 0, 0, MOAIEaseType.SOFT_SMOOTH )
	leafCurve:setKey ( 2, 1, 1, MOAIEaseType.SOFT_SMOOTH )
	leafCurve:setKey ( 3, 2, 0, MOAIEaseType.SOFT_SMOOTH )
	
	tropics.leaf3Anim = MOAIAnim.new ()
	tropics.leaf3Anim:reserveLinks ( 1 )
	tropics.leaf3Anim:setLink ( 1, leafCurve, rightLeaf3, MOAIProp2D.ATTR_Z_ROT )
	tropics.leaf3Anim:setMode ( MOAITimer.LOOP )
	tropics.leaf3Anim:setSpeed ( .75 )

	tropics.leaf2Anim = MOAIAnim.new ()
	tropics.leaf2Anim:reserveLinks ( 1 )
	tropics.leaf2Anim:setLink ( 1, leafCurve, rightLeaf2, MOAIProp2D.ATTR_Z_ROT )
	tropics.leaf2Anim:setMode ( MOAITimer.LOOP )
	tropics.leaf2Anim:setSpeed ( 1 )
	
	tropics.leaf1Anim = MOAIAnim.new ()
	tropics.leaf1Anim:reserveLinks ( 1 )
	tropics.leaf1Anim:setLink ( 1, leafCurve, rightLeaf1, MOAIProp2D.ATTR_Z_ROT )
	tropics.leaf1Anim:setMode ( MOAITimer.LOOP )
	tropics.leaf1Anim:setSpeed ( .9 )
	
	-- bonus meter
	local bonusFlower = graphics.createSprite ()
	bonusFlower:setDeck ( res.tropics.main )
	bonusFlower:setIndex ( 60 )
	bonusFlower:setLayer ( mainLayer )
	bonusFlower:setPriority ( 19 )
	
	tropics.bonusMeter = graphics.createSprite ()
	tropics.bonusMeter:setDeck ( res.tropics.main )
	tropics.bonusMeter:setIndex ( 11 )
	tropics.bonusMeter:setLayer ( mainLayer )
	tropics.bonusMeter:setPriority ( 20 )
	
	-- level line
	tropics.levelLine = graphics.createSprite ()
	tropics.levelLine:setDeck ( res.tropics.main )
	tropics.levelLine:setIndex ( 22 )
	tropics.levelLine:setLayer ( mainLayer )
	tropics.levelLine:setPriority ( 8 )
	
	-- fill texture
	tropics.levelMeter = graphics.createSprite ()
	tropics.levelMeter:setDeck ( res.tropics.main )
	tropics.levelMeter:setIndex ( 24 )
	tropics.levelMeter:setLayer ( mainLayer )
	tropics.levelMeter:setPriority ( 8 )
	tropics.levelMeter:setLoc ( -368, -264 )
	tropics.levelMeter:setRot ( 2.5 )
	
	-- level notch
	tropics.levelNotch = graphics.createSprite ()
	tropics.levelNotch:setDeck ( res.tropics.main )
	tropics.levelNotch:setIndex ( 23 )
	tropics.levelNotch:setLayer ( mainLayer )
	tropics.levelNotch:setPriority ( 8 )
	
	--- text ---
	tropics.lineText = graphics.createTextbox ()
	tropics.lineText:setFont ( font.load ( TROPICS_MOUNT_POINT .. "/resources/font/hpunk16" ) )
	tropics.lineText:setAlignment ( MOAITextBox.CENTER_JUSTIFY )
	tropics.lineText:setSize ( 70, 50 )
	tropics.lineText:setLoc ( -144, -227 )
	tropics.lineText:setLayer ( mainLayer )
	tropics.lineText:setPriority ( 11 )
	tropics.lineText:setText ( tostring ( curLineIdx ))
	tropics.lineText:setColor ( 255/255, 219/255, 167/255, 1 )
	
	tropics.betText = graphics.createTextbox ()
	tropics.betText:setFont ( font.load ( TROPICS_MOUNT_POINT .. "/resources/font/hpunk16" ) )
	tropics.betText:setAlignment ( MOAITextBox.CENTER_JUSTIFY )
	tropics.betText:setSize ( 140, 50 )
	tropics.betText:setLoc ( -275, -208 )
	tropics.betText:setLayer ( mainLayer )
	tropics.betText:setPriority ( 10 )
	tropics.betText:setText ( tostring ( gamestate.validBets [ curBetIdx ] ))
	tropics.betText:setColor ( 255/255, 219/255, 167/255, 1 )
	
	tropics.totalBet = graphics.createTextbox ()
	tropics.totalBet:setFont ( font.load ( TROPICS_MOUNT_POINT .. "/resources/font/hpunk16" ) )
	tropics.totalBet:setAlignment ( MOAITextBox.CENTER_JUSTIFY )
	tropics.totalBet:setSize ( 240, 50 )
	tropics.totalBet:setLoc ( 5, -255 )
	tropics.totalBet:setRot ( 0, 0, 2 )
	tropics.totalBet:setLayer ( mainLayer )
	tropics.totalBet:setPriority ( 12 )
	tropics.totalBet:setColor ( 0, 0, 0, 1 )
	
	tropics.coinText = graphics.createTextbox ()
	tropics.coinText:setFont ( font.load ( TROPICS_MOUNT_POINT .. "/resources/font/hpunk16" ) )
	tropics.coinText:setAlignment ( MOAITextBox.LEFT_JUSTIFY )
	tropics.coinText:setSize ( 260, 50 )
	tropics.coinText:setLoc ( -5, 242 )
	tropics.coinText:setRot ( 0, 0, 2 )
	tropics.coinText:setLayer ( mainLayer )
	tropics.coinText:setPriority ( 9 )
	tropics.coinText:setColor ( 254/255, 207/255, 139/255, 1 )
	
	tropics.levelText = graphics.createTextbox ()
	tropics.levelText:setFont ( font.load ( TROPICS_MOUNT_POINT .. "/resources/font/hpunk16" ) )
	tropics.levelText:setAlignment ( MOAITextBox.CENTER_JUSTIFY )
	tropics.levelText:setSize ( 80, 50 )
	tropics.levelText:setLoc ( -363, -305 )
	tropics.levelText:setLayer ( mainLayer )
	tropics.levelText:setPriority ( 8 )
	tropics.levelText:setColor ( 0, 0, 0, 1 )
	
	tropics.coinSound = soundmgr.createRapidSoundEffect ( "resources/sound/diner_coin.wav" )
	tropics.buttonSound1 = soundmgr.createSound ( TROPICS_MOUNT_POINT .. "/resources/sound/tropical_button1.wav" )
	tropics.buttonSound2 = soundmgr.createSound ( TROPICS_MOUNT_POINT .. "/resources/sound/tropical_button2.wav" )
	tropics.buttonRustle = soundmgr.createSound ( TROPICS_MOUNT_POINT .. "/resources/sound/tropical_rustling.wav" )
	tropics.ambientNoise = soundmgr.createSound ( TROPICS_MOUNT_POINT .. "/resources/sound/wave_ambience.ogg" )
	tropics.ambientNoise:setVolume ( .5 )
	tropics.ambientNoise:setLooping ( true )
	
	-------------------------
	-- Machine
	-------------------------
	tropics.machine = util.doFile ( TROPICS_MOUNT_POINT .. "/gameplay/classic-tropics-machine.lua", mainLayer, -263, 135 )
	tropics.machine:setActiveLines ( 1 )
	
	tropics.theLines = {}
	local lineDecks = {
		res.tropics.lines1_12, res.tropics.lines1_12, res.tropics.lines1_12, res.tropics.lines1_12, res.tropics.lines1_12, res.tropics.lines1_12, res.tropics.lines1_12, res.tropics.lines1_12, res.tropics.lines1_12, res.tropics.lines1_12, res.tropics.lines1_12, res.tropics.lines1_12, 
		res.tropics.lines13_21, res.tropics.lines13_21, res.tropics.lines13_21, res.tropics.lines13_21, res.tropics.lines13_21, res.tropics.lines13_21, res.tropics.lines13_21, res.tropics.lines13_21, res.tropics.lines13_21, 
		res.tropics.lines22_24, res.tropics.lines22_24, res.tropics.lines22_24
	}
	for i = 1, MAX_LINES do
		
		local line = graphics.createSprite ()
		line:setDeck ( lineDecks [ i ] )
		line:setIndex ( i )
		line:setLayer ( mainLayer )
		line:setPriority ( 9 )
		line:setLoc ( 0, 0 )
		line:setVisible ( false )
		
		local light = graphics.createSprite ()
		light:setDeck ( res.tropics.main )
		light:setLayer ( mainLayer )
		light:setPriority ( 8 )
		light:setColor ( 1, 1, 1, 1 )
		light:setVisible ( false )
		setLightIndex ( light, i )
		line.light = light
		
		table.insert ( tropics.theLines, line )
	end
	
	tropics.machine:setWinLines ( tropics.theLines )
	
	updateLineText ()
	-------------------------
end

----------------------------------------------------------------
tropics.onLoseFocus = function ( self )
	
	tropics.ambientNoise:stop ()
end

----------------------------------------------------------------
tropics.onUnload = function ( self )
	
	for i, layerSet in ipairs ( self.layerTable ) do
		
		for j, layer in ipairs ( layerSet ) do
		
			layer = nil
		end
	end
	
	self.layerTable = nil
	mainLayer = nil
	

end

----------------------------------------------------------------
tropics.onUpdate = function ( self )

	if triggerMedWin then
		
		triggerMedWin = false
		statemgr.push ( TROPICS_MOUNT_POINT .. "/states/state-medwin-tropics.lua" )
		return
	elseif triggerBigWin then
		
		triggerBigWin = false
		statemgr.push ( TROPICS_MOUNT_POINT .. "/states/state-bigwin-tropics.lua" )
		return
	elseif triggerMaxWin then

		triggerMaxWin = false
		statemgr.push ( TROPICS_MOUNT_POINT .. "/states/state-maxwin-tropics.lua" )
		return
	elseif triggerXp then
		
		if not gaveFreeSpins then
			
			statemgr.push ( "states/state-levelup-popup.lua", gamestate.level )		
			triggerXp = false
			updateXpBar ()
		end	
	elseif triggerBonus then

		--bonusSound:play ()
		--bonusParticles:start ()
		--bonusAnim:start ()
		--stopAnimAfterSeconds ( bonusParticles, 1.5 )
		triggerBonus = false

		bonusdata.bet = gamestate.validBets [ curBetIdx ] * curLineIdx

		statemgr.push ( TROPICS_MOUNT_POINT .. "/states/state-bonus-tropics.lua", bonusdata )
		return
	end
	
	if inputmgr.isDown () and not tropics.machine:isSpinning () and not showingWins then
		local x, y = mainLayer:wndToWorld ( inputmgr.getTouch ())
		
		tropics.spinButton:interactButton ( x, y )
		tropics.maxButton:interactButton ( x, y )
		tropics.storeButton:interactButton ( x, y )
		tropics.menuButton:interactButton ( x, y )
	else	
		tropics.spinButton:onRelease ()
		tropics.maxButton:onRelease ()
		tropics.storeButton:onRelease ()
		tropics.menuButton:onRelease ()
	end
	
	if not tropics.machine:isSpinning () and continuousSpin == true and not showingWins and not triggerBonus then

		local thisBet = gamestate.validBets [ curBetIdx ] * curLineIdx

		if thisBet <= gamestate.coins then
	
			if not tropics.machine:isSpinning () then
			
			
				spinThread:stop ()
				showingWins = true
				spinThread:run ( spinFunc )
				savefile.saveGame ( gamestate, "gamestate.lua" )
			end
		else
			-- inform the player of insufficient funds, point to coin store
		
			statemgr.push ( "states/state-notify-popup.lua", localizedText.brassMain.notEnough, 33, localizedText.brassMain.purchase, localizedText.brassMain.get, function ()
					statemgr.pop ()
					statemgr.push ( "states/state-store-popup.lua", storeTable )
				end )
		end
	end
end

return tropics