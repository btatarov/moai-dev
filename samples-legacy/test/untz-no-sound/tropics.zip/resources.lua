--==============================================================
-- Copyright (c) 2010-2011 Zipline Games, Inc. 
-- All Rights Reserved. 
-- http://getmoai.com
--==============================================================

local args = { ... }

TROPICS_MOUNT_POINT = args [ 1 ]
print ('res', TROPICS_MOUNT_POINT)

resources {
	tropics = {
		main = function ( )
			return flash.makeSpriteDeck ( TROPICS_MOUNT_POINT .. "/resources/WS_TropicalDeck.fla.lua" )
		end,		
		
		main2 = function ( )
			return flash.makeSpriteDeck ( TROPICS_MOUNT_POINT .. "/resources/WS_TropicalDeck2.fla.lua" )
		end,		
		
		icons = function ( )
			return flash.makeSpriteDeck ( TROPICS_MOUNT_POINT .. "/resources/WS_TropicalDeckIcons.fla.lua" )
		end,
		
		bonus = function ( )
			return flash.makeSpriteDeck ( TROPICS_MOUNT_POINT .. "/resources/WS_TropicalDeckBonus.fla.lua" )
		end,
		
		lines1_12 = function ( )
			return flash.makeSpriteDeck ( TROPICS_MOUNT_POINT .. "/resources/WS_TropicalPayLines1-12.fla.lua" )
		end,
		
		lines13_21 = function ( )
			return flash.makeSpriteDeck ( TROPICS_MOUNT_POINT .. "/resources/WS_TropicalPayLines13-21.fla.lua" )
		end,
		
		lines22_24 = function ( )
			return flash.makeSpriteDeck ( TROPICS_MOUNT_POINT .. "/resources/WS_TropicalPayLines22-24.fla.lua" )
		end,
	}
}