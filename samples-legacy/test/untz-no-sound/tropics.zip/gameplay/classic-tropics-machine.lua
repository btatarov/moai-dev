--==============================================================
-- Copyright (c) 2010-2011 Zipline Games, Inc. 
-- All Rights Reserved. 
-- http://getmoai.com
--==============================================================

local args = { ... }
local layer = args [ 1 ]
local x = args [ 2 ]
local y = args [ 3 ]

----------------------------------------------------------------
-- Spritedeck and icon list
----------------------------------------------------------------
local spritedeck = res.tropics.icons

local idxTable = {
	{ index = 1, anim = nil, animFrames = nil },
	{ index = 2, anim = nil, animFrames = nil },
	{ index = 3, anim = nil, animFrames = nil },
	{ index = 4, anim = nil, animFrames = nil },
	{ index = 5, anim = nil, animFrames = nil },
	{ index = 6, anim = nil, animFrames = nil },
	{ index = 7, anim = nil, animFrames = nil },
	{ index = 8, anim = nil, animFrames = nil },
	{ index = 9, anim = { filename = TROPICS_MOUNT_POINT .. "/resources/WS_TropicalFlipbook.fla.lua", startFrame = 1, endFrame = 6 }, animFrames = { st = 1, fn = 6 }, animSpeed = .5, animLooping = true },
}

local bounceOn = true
local blurOn = true

local xform = MOAITransform2D.new ()
xform:setRot ( -2 )

local reelPositions = {
	[ 1 ] = { xLoc = x, yLoc = y },
	[ 2 ] = { xLoc = x, yLoc = y },
	[ 3 ] = { xLoc = x, yLoc = y },
	[ 4 ] = { xLoc = x, yLoc = y },
	[ 5 ] = { xLoc = x, yLoc = y },
	
	reelParent = xform
}

local iconSize = 112
local iconPadX = 22
local iconPadY = 12
local blurOffset = 9

local slotMachine = util.doFile ( "gameplay/classic-base-machine.lua", layer, reelPositions, spritedeck, idxTable, iconSize, iconPadX, iconPadY, bounceOn, blurOn, holdsOn, .9, blurOffset, { boxDeck = res.spritedeck.diner, boxIndex = 74, winAnim = { filename = TROPICS_MOUNT_POINT .. "/resources/WS_TropicalFlipbook.fla.lua", startFrame = 125, endFrame = 135 } } )

dofile ( "machine/algorithm.lua" )
dofile ( "machine/board.lua" )
dofile ( "machine/machine.lua" )
dofile ( "machine/pickle.lua" )
dofile ( "machine/tally.lua" )
dofile ( "machine/util.lua" )
local machine = Machine.new ()
local algorithm = Algorithm.new ()

local cwd = MOAIFileSystem.getWorkingDirectory ()
MOAIFileSystem.setWorkingDirectory ( dlcmgr.getDLCDirectory () )

--[[if MOAIFileSystem.checkFileExists ( "chineseny-settings" ) then
	
	print "new settings"
	local file = assert ( io.open ( "chineseny-settings", 'rb' ) )
	local settings = file:read ( '*a' )
	file:close ()
	settings = MOAIDataBuffer.base64Decode ( settings )
	settings = MOAIDataBuffer.inflate ( settings )
	settings = loadstring ( settings ) ()
	slotMachine:setReelSizes ( settings.reelSizes )
	algorithm.setGenFunc ( settings.genFunc )
	if not gamestate.nextBonusMax then gamestate.nextBonusMax = {} end
	if not gamestate.bonusRewards then gamestate.bonusRewards = {} end
	gamestate.nextBonusMax.chineseny = settings.bonusMax
	gamestate.bonusRewards.chineseny = settings.bonusRewards
	MOAIFileSystem.deleteFile ( "chineseny-settings" )
	
elseif MOAIFileSystem.checkFileExists ( "chineseny-algSave" ) then

	print "loading alg"
	local file = io.open ( "chineseny-algSave", "rb" )
	if file then		
		local lineStr = file:read ( '*a' )
		file:close ()
		lineStr = MOAIDataBuffer.inflate ( lineStr )
		local algTable = loadstring ( lineStr ) ()
		algorithm.loadAlgorithm ( algTable.algorithm )
		slotMachine:setReelSizes ( algTable.reels )
	end

else]]--
	
	print "default"
	slotMachine:setReelSizes ({ 6, 12, 20, 30, 42 })
	local function genFunc ( algorithm )
	
		algorithm.pushState ()
		algorithm.setPayout ( .95 )
		algorithm.setDuration ( 20 )
		algorithm.setWeightCurve ( 0, .25, 100000, 1, Algorithm.EASE_IN, 45 )
		
		algorithm.pushState ()
		algorithm.setPayout ( 1.1 )
		algorithm.setDuration ( 10 )
		algorithm.setWeightCurve ( 0.25, 0.5, 200000, 1, Algorithm.EASE_IN, 45 )
		
		algorithm.pushState ()
		algorithm.setPayout ( 0.85 )
		algorithm.setDuration ( 20 )
		algorithm.setWeightCurve ( 0.25, 0.5, 200000, 1, Algorithm.EASE_IN, 45 )

		algorithm.pushState ()
		algorithm.setPayout ( 1.2 )
		algorithm.setDuration ( 10 )
		algorithm.setWeightCurve ( 0, 1, 200000, 1, Algorithm.EASE_IN, 45 )

	end
	algorithm.setGenFunc ( genFunc )
	gamestate.lineTables [ "tropics" ] = "../lua/machine/lineTables/chineseny/"
--end

slotMachine:setLineTableDir ( gamestate.lineTables [ "tropics" ])

MOAIFileSystem.setWorkingDirectory ( cwd )

slotMachine:setMachineAlgorithm ( machine, algorithm )
slotMachine:setIconTransfer (
	{
		1,
		2,
		3,
		4,
		5,
		6,
		7,
		8,
		9,
	}
)

local lineTable
local file = io.open ( "machine/lineTables/chineseny/1-lines", 'rb' )
if file then
	local lineStr = file:read ( '*a' )
	file:close ()
	lineStr = MOAIDataBuffer.inflate ( lineStr )
	lineTable = loadstring ( lineStr ) ()
end
slotMachine:setPayTable ( lineTable.symbols )

slotMachine.maxJackpot = Machine.LARGE
slotMachine.largeJackpot = Machine.MED
slotMachine.medJackpot = Machine.SMALL

slotMachine:setSounds ( {
	highlightSound = soundmgr.createRapidSoundEffect ( TROPICS_MOUNT_POINT .. "/resources/sound/tropical_win_highlight.wav" ),
	spinningSong = soundmgr.createSound ( TROPICS_MOUNT_POINT .. "/resources/sound/tropical_spin.ogg" ),
	reelStopSound = soundmgr.createSound ( TROPICS_MOUNT_POINT .. "/resources/sound/tropical_reel_stop.wav" )
})

return slotMachine
