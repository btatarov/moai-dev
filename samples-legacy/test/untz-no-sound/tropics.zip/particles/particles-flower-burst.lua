-- ==============================================================
-- Copyright (c) 2010-2011 Zipline Games, Inc. 
-- All Rights Reserved. 
-- http://getmoai.com
-- ==============================================================

local args = { ... }

------------------------------------------------------------
local rig = {}

local r1 = MOAIParticleScript.packReg ( 1 )
local r2 = MOAIParticleScript.packReg ( 2 )
local r3 = MOAIParticleScript.packReg ( 3 )
local r4 = MOAIParticleScript.packReg ( 4 )
local s0 = MOAIParticleScript.packReg ( 5 )
local pRot = MOAIParticleScript.packReg ( 6 )
local pSclX = MOAIParticleScript.packReg ( 7 )
local pSclDX = MOAIParticleScript.packReg ( 8 )
-- local pR = MOAIParticleScript.packReg ( 9 )
-- local pG = MOAIParticleScript.packReg ( 10 )
-- local pB = MOAIParticleScript.packReg ( 11 )
-- local r5 = MOAIParticleScript.packReg ( 12 )

local CONST = MOAIParticleScript.packConst

------------------------------------------------------------
local init1 = MOAIParticleScript.new ()
	
	init1:randVec		( r1, r2, CONST ( 140 ), CONST ( 180 ))
	init1:rand			( r3, CONST ( -28 ), CONST ( -128 ))
	init1:rand			( r4, CONST ( 8 ), CONST ( 10 +1 ) )
	init1:rand			( pRot, CONST ( -360 ), CONST ( 360 ))
	init1:set			( pSclX, CONST ( 1 ))
	init1:rand			( pSclDX, CONST ( 0.1 ), CONST ( 0.2 ))
	
	-- init1:rand			( pR, CONST ( 0.2 ), CONST ( 1.0 ))
	-- init1:rand			( pG, CONST ( 0.2 ), CONST ( 1.0 ))
	-- init1:rand			( pB, CONST ( 0.2 ), CONST ( 1.0 ))
	init1:set			( MOAIParticleScript.PARTICLE_DY, CONST ( -64 ))

------------------------------------------------------------
local render1 = MOAIParticleScript.new ()

	render1:easeDelta	( MOAIParticleScript.PARTICLE_X, CONST ( 0 ), r1, MOAIEaseType.EASE_IN )
	render1:easeDelta	( MOAIParticleScript.PARTICLE_Y, CONST ( 0 ), r2, MOAIEaseType.EASE_IN )

	render1:sprite		()
	render1:set			( MOAIParticleScript.SPRITE_IDX, r4 )
	render1:ease		( MOAIParticleScript.SPRITE_ROT, CONST ( 0 ), r3, MOAIEaseType.EASE_IN )
	
	-- render1:set 		( MOAIParticleScript.SPRITE_GLOW, CONST ( 1.0 )  )
	-- render1:set			( MOAIParticleScript.SPRITE_RED, CONST ( 1.0 ))
	-- render1:set			( MOAIParticleScript.SPRITE_GREEN, CONST ( 0.7 ) )
	-- render1:set			( MOAIParticleScript.SPRITE_BLUE, CONST ( 0.3 ) )
	
----------------------------------------------------------------
local init2 = MOAIParticleScript.new ()
	
----------------------------------------------------------------
local render2 = MOAIParticleScript.new ()

	render2:ease		( s0, CONST ( 0 ), pSclDX, MOAIEaseType.EASE_IN )
	render2:add			( pSclX, pSclX, s0 )
	render2:cycle		( s0, pSclX, CONST ( .5 ), CONST ( 1 ))
	-- render2:easeDelta	( MOAIParticleScript.PARTICLE_DY, CONST ( 0 ), r3, MOAIEaseType.EASE_IN )

	render2:sprite		()
	render2:set			( MOAIParticleScript.SPRITE_IDX, r4 )
	render2:ease		( MOAIParticleScript.SPRITE_ROT, CONST ( 0 ), pRot, MOAIEaseType.EASE_IN )
	render2:set			( MOAIParticleScript.SPRITE_X_SCL, s0 )
	render2:rand		( MOAIParticleScript.SPRITE_Y_SCL, s0 )
	render2:ease		( MOAIParticleScript.SPRITE_OPACITY, CONST ( 1 ), CONST ( 0 ), MOAIEaseType. EASE_IN)
	
	render2:rand 		( MOAIParticleScript.SPRITE_GLOW, CONST ( 0.5 ), CONST ( 0.75 )  )
	-- render2:set			( MOAIParticleScript.SPRITE_RED, CONST ( 0.0 ) )
	-- render2:set			( MOAIParticleScript.SPRITE_GREEN, CONST ( 1.0 ) )
	-- render2:set			( MOAIParticleScript.SPRITE_BLUE, CONST ( 1.0 ) )
	
	
------------------------------------------------------------
local gravity = MOAIParticleForce.new ()
gravity:setType ( MOAIParticleForce.FORCE )

local state1 = MOAIParticleState.new ()
state1:setTerm ( 0.5, .75 )
state1:setInitScript ( init1 )
state1:setRenderScript ( render1 )

local state2 = MOAIParticleState.new ()
state2:setTerm ( .5, 1 )
state2:setInitScript ( init2 )
state2:setRenderScript ( render2 )

local system = MOAIParticleSystem.new ()
system:reserveParticles ( 256, 11 )
system:reserveSprites ( 256 )
system:reserveStates ( 2 )
system:setDeck ( res.tropics.bonus )
system:start ()
system:setState ( 1, state1 )

state1:setNext ( state2 )

------------------------------------------------------------
function rig:emit ( x, y )

	system:surge ( 50, x, y )
end

----------------------------------------------------------------
function rig:setLayer ( layer )
	
	layer:insertProp ( system )
end

----------------------------------------------------------------
function rig:setVisible ( visible )
	
	system:setVisible ( visible )
end

function rig:setPriority ( priority )
	
	system:setPriority ( priority )
end

function rig:stop ()
	
	system:stop ()
end

return rig