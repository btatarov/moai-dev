-- ==============================================================
-- Copyright (c) 2010-2011 Zipline Games, Inc. 
-- All Rights Reserved. 
-- http://getmoai.com
-- ==============================================================

local args = { ... }

------------------------------------------------------------
local rig = {}

local r1 = MOAIParticleScript.packReg ( 1 )
local r2 = MOAIParticleScript.packReg ( 2 )
local r3 = MOAIParticleScript.packReg ( 3 )
local r4 = MOAIParticleScript.packReg ( 4 )
local s0 = MOAIParticleScript.packReg ( 5 )
local pRot = MOAIParticleScript.packReg ( 6 )
local pSclX = MOAIParticleScript.packReg ( 7 )
local pSclDX = MOAIParticleScript.packReg ( 8 )
local pR = MOAIParticleScript.packReg ( 9 )
local pG = MOAIParticleScript.packReg ( 10 )
local pB = MOAIParticleScript.packReg ( 11 )

local CONST = MOAIParticleScript.packConst

------------------------------------------------------------
local init1 = MOAIParticleScript.new ()
	
	init1:rand			( r1, CONST ( -50 ), CONST ( 100 ) )
	init1:rand			( r2, CONST ( 30 ), CONST ( 300 ) )
	init1:rand			( r3, CONST ( -8 ), CONST ( 8 ))
	init1:set			( r4, CONST ( 199 ))
	-- init1:rand			( pRot, CONST ( -360 ), CONST ( 360 ))
	init1:rand			( pSclX, CONST ( 0.5 ), CONST ( 1 ) )
	init1:rand			( pSclDX, CONST ( 0.1 ), CONST ( 0.2 ))
	
	init1:rand			( pR, CONST ( 0.5 ), CONST ( 1.0 ))
	init1:rand			( pG, CONST ( 0.75 ), CONST ( 1.0 ))
	init1:rand			( pB, CONST ( 0.75 ), CONST ( 1.0 ))
	-- init1:set			( MOAIParticleScript.PARTICLE_DY, CONST ( 96 ))

------------------------------------------------------------
local render1 = MOAIParticleScript.new ()

	-- render1:easeDelta	( MOAIParticleScript.PARTICLE_X, CONST ( 0 ), r1, MOAIEaseType.SHARP_EASE_IN )
	-- render1:easeDelta	( MOAIParticleScript.PARTICLE_Y, CONST ( 0 ), r2, MOAIEaseType.EASE_IN )
	-- render1:set	( MOAIParticleScript.PARTICLE_DX, r1 )
	render1:easeDelta	( MOAIParticleScript.PARTICLE_DX, CONST( 0 ) , r1,  MOAIEaseType.EASE_IN )
	render1:easeDelta	( MOAIParticleScript.PARTICLE_DY, CONST( 0 ), r2, MOAIEaseType.EASE_IN )
	-- render1:set	( MOAIParticleScript.PARTICLE_DY, r2 )

	render1:ease		( s0, CONST ( 0.05 ), pSclDX, MOAIEaseType.EASE_IN )
	render1:add			( pSclX, pSclX, s0 )
	render1:cycle		( s0, pSclX, CONST ( .6 ), CONST ( 1.5 ))

	render1:sprite		()
	render1:set			( MOAIParticleScript.SPRITE_IDX, CONST ( 25 ) )
	-- render1:ease		( MOAIParticleScript.SPRITE_ROT, CONST ( 0 ), pRot, MOAIEaseType.EASE_IN )
	render1:set			( MOAIParticleScript.SPRITE_X_SCL, s0 )
	render1:set			( MOAIParticleScript.SPRITE_Y_SCL, s0 )
	
	render1:set			( MOAIParticleScript.SPRITE_RED, CONST ( 0 ) )
	render1:set			( MOAIParticleScript.SPRITE_GREEN, pG )
	render1:set			( MOAIParticleScript.SPRITE_BLUE, pB )
	render1:rand 		( MOAIParticleScript.SPRITE_GLOW, CONST ( 0.5 ), CONST ( 0.90 )  )
	render1:ease		( MOAIParticleScript.SPRITE_OPACITY, CONST (.8) , CONST( 0 ), MOAIEaseType.EASE_OUT )
	
	
------------------------------------------------------------
local gravity = MOAIParticleForce.new ()
gravity:setType ( MOAIParticleForce.FORCE )
gravity:initAttractor (  10, -100 )

local state1 = MOAIParticleState.new ()
state1:setTerm ( 1, 3 )
state1:setInitScript ( init1 )
state1:setRenderScript ( render1 )
-- state1:pushForce ( gravity )

local system = MOAIParticleSystem.new ()
system:reserveParticles ( 1024, 11 )
system:reserveSprites ( 1024 )
system:reserveStates ( 1 )
system:setDeck ( res.tropics.main )
system:start ()
system:setState ( 1, state1 )

state1:setNext ( state2 )

local emitter = MOAIParticleTimedEmitter.new ()
emitter:setAngle ( 85, 95 ) 
emitter:setLoc ( 0, 0 )
emitter:setSystem ( system )
emitter:setMagnitude ( 10, 20 )
emitter:setFrequency ( 0.02)
emitter:setRadius ( 0)
emitter:setEmission ( 20 )

------------------------------------------------------------
function rig:emit ( x, y )

	system:surge ( 128, x, y )
end

function rig:setParent ( parent )
	
	emitter:setParent ( parent )
end

function rig:start ()

	emitter:start ()
end

function rig:stop ()

	emitter:stop ()
end

function rig:getEmitter ()
	
	return emitter
end

----------------------------------------------------------------
function rig:setLoc ( x, y )
	
	emitter:setLoc ( x, y )
end

----------------------------------------------------------------
function rig:setLayer ( layer )
	
	layer:insertProp ( system )
end

----------------------------------------------------------------
function rig:setPriority ( priority )
	
	system:setPriority ( priority )
end

----------------------------------------------------------------
function rig:setVisible ( visible )
	
	system:setVisible ( visible )
end

----------------------------------------------------------------
function rig:isBusy ()
	
	emitter:isBusy ()
end

------------------------------------------------------------
return rig